AttackWebFrameworkTools 使用说明

url.txt 中网站一行一个且必须以http:// https:// 开头

AttackWebFrameworkTools.exe 所有exp都跑

AttackWebFrameworkTools.exe -type thinkphp 使用默认线程跑 thinkphp框架漏洞

AttackWebFrameworkTools.exe -type thinkphp -thread 200 使用自定义线程 线程跑 thinkphp框架漏洞

集成漏洞如下(-type参数) 
thinkphp
weblogic
struts2
hadoop
atlassiancrowd
ueditor
tongdaoa
apacheflink
ruijie
apachedruid
dlink
如果会在软件同目录下生产shell.txt。攻击不成功则不会生成

软件使用注意事项
(1)非回显漏洞采用dnslog 验证确保联网。如果在局域网不联网环境下dnslog验证的漏洞全部无法验证。
(2)遇到postData是jason格式时候必须 Content-type:application/json 而不是默认格式
(3)Dlink漏洞需要有AttackWebFrameworkTools.exe.config 并且一个网站一分钟内最多可以检测三次超过三次即使漏洞存在也检测不到 这个目前反弹shell方式不清楚


建议进行针对对性漏洞测试全量跑耗时就容易被waf封杀



